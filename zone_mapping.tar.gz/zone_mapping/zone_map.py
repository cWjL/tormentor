from pyvis.network import Network
from datetime import datetime
import networkx as nx
import os, sys, argparse
import itertools, threading
import time, queue

DONE = False
res_q = queue.Queue()
def main():
	'''
	Zone map visualization script
	'''

	parser = argparse.ArgumentParser()
	reqd = parser.add_argument_group('required arguments')
	mode_args = parser.add_argument_group('mode options')
	mode_args.add_argument('-m','--map-mode',action='store_true',dest='map',help='Create visual graph of network nodes')
	mode_args.add_argument('-r','--report-only', action='store_true', dest='report', help='Print report only, no map')
	mode_args.add_argument('-M', '--max-nodes', action='store', dest='max', help='Maximum nodes to generate')
	reqd.add_argument('-i', '--input-dir', action='store', dest='inp', help='Directory contaning .map files', required=True)
	parser.add_argument('-o', '--out', action='store', dest='out', help='Output directory')

	args = parser.parse_args()

	prefixes = ["[*] ", "[x] ", "[+] ", "[-] ", "[?] "]
	file_base = "zone-map-"+datetime.utcnow().strftime('%Y%m%d%H%M%S%f')

	map_files = []
	wait = threading.Thread(target=animate)
	MAX_HOSTS = 50

	if args.map and args.report:
		print(prefixes[1]+"Select \'-m\' or \'-r\', not both")
		sys.exit(1)

	if args.map and not args.max:
		print(prefixes[1]+"You must supply \'-M\' max nodes to use this option")
		sys.exit(1)

	# Get map files
	if not os.path.isdir(args.inp):
		print(prefixes[1]+"Input path must point to a directory")
		sys.exit(1)
	else:
		for file in os.listdir(args.inp):
			if file.endswith(".map"):
				map_files.append(os.path.join(args.inp, file))
		if len(map_files) < 1:
			print(prefixes[1]+"No map files found.  Check the directory you supplied")
			sys.exit(1)

	if args.out:
		if not os.path.isdir(args.out):
			print(prefixes[1]+"Output path must point to a directory")
			sys.exit(1)
		else:
			out_path = os.path.abspath(args.out)
			if os.name == 'posix':
				out_path += '/'
			else:
				out_path += '\\'
			file_base = out_path+file_base

	map_list = []
	thread_list = []
	print(prefixes[0]+"Fetching map files...")
	for file_p in map_files:
		if args.max is not None:
			thread_list.append(threading.Thread(target=_parse_files, args=(int(args.max), file_p)))
		else:
			thread_list.append(threading.Thread(target=_parse_files, args=(file_p,)))

	for th in thread_list:
		th.daemon = True
		th.start()

	for th in thread_list:
		th.join()

	while res_q.qsize() > 0:
		map_list.append(res_q.get())

	print(prefixes[0]+"Done")
	print(prefixes[0]+"Mapping zone relationships...")
	relate = _define_relationships(map_list)

	print(prefixes[0]+"Done")
	network = NetworkInfo(map_list)
	if not args.report:
		print(prefixes[0]+"Starting zone graph...")
		wait.start()
		_print_graph(map_list, relate, network, file_base)

	print(prefixes[0]+"Generating report...")

	with open(file_base+".txt", 'w') as report:
		report.write("Zone Mapping Report:\n\n")
		report.write("Zone Mapping Statistics:\n\n")
		for r_map in map_list:
			report.write("\tSource Zone: "+r_map.src_zone.strip()+" Source IP: "+r_map.src_ip+"\n")
			for r_targets in r_map.targets:
				report.write("\t\tTarget Zone: "+r_targets.zone.strip()+" / Host Count: "+str(len(r_targets.hosts))+"\n")
			report.write('\n')
		report.write("\nInter-Zone Relationships\n\n")
		report.write("\t------------------------------------\n")
		report.write("\t| SRC ZONE | DST ZONE | REACHABLE? |\n")
		report.write("\t------------------------------------\n")
		for k, v in relate.MAPPED.items():
			zones = k.split("->")
			if v:
				report.write("\t|   "+zones[0]+"    |   "+zones[1]+"    |   "+str(v)+"     |\n")
			else:	
				report.write("\t|   "+zones[0]+"    |   "+zones[1]+"    |   "+str(v)+"    |\n")
		report.write("\t------------------------------------\n")
	print(prefixes[0]+"Report written to "+file_base+".txt")
	sys.exit(0)

def _parse_files(map_list, max=None):
	'''
	.map file parse thread function. Adds list of MapData object to list and
	drops in global queue

	:param max: integer max number of nodes to create for each zone
	:param map_list: .map file pointers
	'''
	with open(map_list, 'r') as mapit:
		raw_report = mapit.readlines()
	if "SRC_ZONE" in raw_report[0]:
		src_name = raw_report.pop(0).split(" ")
		src_ip = raw_report.pop(0).split(" ")
		map_info = MapData(src_name[1], src_ip[1])

	hosts = []

	if "TARGET_ZONE" in raw_report[0]:
		curr_name = raw_report.pop(0).split(" ")[1]
		map_info.add_target(curr_name)

	host_count = 0
	for line in raw_report:
		if "TARGET_ZONE" in line:
			map_info.add_hosts(curr_name, hosts)
			curr_name = line.split(" ")[1]
			map_info.add_target(curr_name)
			host_count = 0
			hosts = []
		else:
			if max is not None:
				if host_count < max:
					hosts.append(line)
					host_count += 1
			else:
				hosts.append(line)

	map_info.add_hosts(curr_name, hosts)
	res_q.put(map_info)
	return


def _define_relationships(map_list):
	'''
	Determine which zones can talk to each other

	:param map_list: List of MapData objects
	:return relate: Zone relationship dictionary
	'''
	relate = Relationships

	for i_map in map_list:
		for tar in i_map.targets:
			if tar.reachable:
				relate.MAPPED[i_map.src_zone.strip()+'->'+tar.zone.strip()] = True
	return relate

def _print_graph(map_list, relations, network, file_base):
	'''
	Graph the network nodes, edges, and zone to zone connections

	:param map_list: List of MapData objects
	:param relations: Zone relationship dictionary
	:param network: NetworkInfo object
	'''
	global DONE

	net = Network(height="100%", width="100%", bgcolor="#222222", font_color="white")
	net.barnes_hut(central_gravity=1.0)
	nx_graph = nx.Graph()

	sub_nets = []

	for k, v in network.NETWORKS.items():
		if len(v) > 0:
			sub_nets.append((k, v))

	i = j = 0
	zones_con = []
	edges = []
	edge_list = []
	# Add subnet host nodes
	for sub in sub_nets:
		for ip in sub[1]:
			edge_list.append(i)
			nx_graph.add_node(i, size=15, title=sub[0].strip()+":"+ip, label=ip, group=j)
			i += 1

		# Adds all zone node IDs to list mapped to zone name
		network.set_nodes(sub[0].strip(), edge_list)

		# Add edges based on 2-node permutations of all nodes in this zone
		# Connects all nodes in the zone
		nx_graph.add_edges_from(list(itertools.permutations(edge_list, 2)), weight=2)
		# Reset edge list
		edge_list = []
		j += 1

	# Get cross-zone edges
	for zone, reachable in relations.MAPPED.items():
		if reachable:
			zone_pair = zone.split('->')
			node_0 = network.get_node(zone_pair[0])
			node_1 = network.get_node(zone_pair[1])
			if node_0 is not None and node_1 is not None:
				# Add zone to zone edges
				nx_graph.add_edge(node_0,node_1,
					color='green',label=zone_pair[0]+" to "+zone_pair[1], width=10.0, label_font=24)

	net.from_nx(nx_graph)
	#net.show_buttons(filter_=['physics'])
	net.show(file_base+".html")
	DONE = True

def animate():
	'''
	Wait animation thread
	'''
	global DONE
	for c in itertools.cycle(['|', '/', '-', '\\']):
		print('\r'+'[*] Graphing ' + c, end='')
		time.sleep(0.1)
		if DONE:
			print('\r'+'                ', end='')
			print('\r'+'[*] Done', end='\n')
			break

class MapData:
	'''
	Stores Target objects and src zone name and IP

	:param src_zone: Scan origination zone name
	:param src_ip: Scan origination host IP
	'''

	def __init__(self, src_zone, src_ip):
		self.src_zone = src_zone
		self.src_ip = src_ip
		self.targets = []

	def add_target(self, name):
		'''
		Add Target object to list
		'''
		self.targets.append(Target(name))

	def add_hosts(self, name, hosts):
		'''
		Add host to sepcified target zone
		'''
		for tar in self.targets:
			if tar.zone == name:
				tar.add_hosts(hosts)

class Target:
	'''
	Stores target zone name, if it's reachable from the src zone, and 
	resident host IPs

	:param zone: Zone name
	'''

	def __init__(self, zone):
		self.zone = zone
		self.hosts = []
		self.reachable = True

	def add_hosts(self, hosts):
		'''
		Add list to existing list
		'''
		if len(hosts) > 0:
			self.hosts.extend(hosts)
		else:
			self.reachable = False

	def set_reachable(self, reachable):
		'''
		Set reachable
		'''
		self.reachable = reachable

class NetworkInfo:
	'''
	Stores network information: node IDs, subnet IPs

	:param mapped: List of MapData objects
	'''

	def __init__(self, mapped):
		self.mapped = mapped
		self._set_zone_lists()
		self._set_zone_nodes()
		self.ZONE_NODES = {
				'COR':self.COR_NODE,
				'PRD':self.PRD_NODE,
				'MGT':self.MGT_NODE,
				'PKI':self.PKI_NODE,
				'PCI':self.PCI_NODE,
				'PCA':self.PCA_NODE,
				'MAH':self.MAH_NODE,
				'CMH':self.CMH_NODE,
				'INTERNET':self.INTERNET_NODE
				}
		self.NETWORKS = {
				'COR':self.COR,
				'PRD':self.PRD,
				'MGT':self.MGT,
				'PKI':self.PKI,
				'PCI':self.PCI,
				'PCA':self.PCA,
				'MAH':self.MAH,
				'CMH':self.CMH,
				'INTERNET':self.INTERNET
				}
		self._get_networks()

	def _set_zone_nodes(self):
		self.COR_NODE = []
		self.PRD_NODE = []
		self.MGT_NODE = []
		self.PKI_NODE = []
		self.PCI_NODE = []
		self.PCA_NODE = []
		self.MAH_NODE = []
		self.CMH_NODE = []
		self.INTERNET_NODE = []

	def _set_zone_lists(self):
		self.COR = []
		self.PRD = []
		self.MGT = []
		self.PKI = []
		self.PCI = []
		self.PCA = []
		self.MAH = []
		self.CMH = []
		self.INTERNET = []

	def _get_networks(self):
		'''
		Initialize subnet lists with IPs from MapData objects
		'''
		for i_map in self.mapped:
			if i_map.src_zone.strip() == "INTERNET":
				shitty_hack = []
				shitty_hack.append(str(i_map.src_ip.strip()))
				self._update(i_map.src_zone.strip(), shitty_hack)
			for tar in i_map.targets:
				if len(tar.hosts) > 0:
					self._update(tar.zone.strip(), tar.hosts)

	def _update(self, zn, lst):
		'''
		Set IP addresses for the requested zone, ignore duplicates
		'''
		self.NETWORKS[zn].extend(set(lst))

	def get_network(self, zn):
		'''
		Get list of IP for the requested zone
		'''
		return self.NETWORKS[zn.strip()]

	def set_nodes(self, zn, nodes):
		'''
		Define a list of nodes for specified zone
		'''
		self.ZONE_NODES[zn].extend(nodes)

	def get_node(self, zn):
		'''
		Get one node from requested zone
		'''
		if len(self.ZONE_NODES[zn.strip()]) > 0:
			if zn == "INTERNET":
				print(self.ZONE_NODES[zn.strip()][0])
				return self.ZONE_NODES[zn.strip()][0]
			else:
				return self.ZONE_NODES[zn.strip()].pop(0)
		else:
			return None

class Relationships:
	'''
	Defines zone to zone relationships
	'''
	
	MAPPED = {
				'COR->PRD':False,
				'COR->MGT':False,
				'COR->PCI':False,
				'COR->PCA':False,
				'COR->PKI':False,
				'COR->MAH':False,
				'COR->CMH':False,
				'PRD->COR':False,
				'PRD->MGT':False,
				'PRD->PCI':False,
				'PRD->PCA':False,
				'PRD->PKI':False,
				'PRD->MAH':False,
				'PRD->CMH':False,
				'MGT->COR':False,
				'MGT->PRD':False,
				'MGT->PCI':False,
				'MGT->PCA':False,
				'MGT->PKI':False,
				'MGT->MAH':False,
				'MGT->CMH':False,
				'PCI->COR':False,
				'PCI->PRD':False,
				'PCI->MGT':False,
				'PCI->PCA':False,
				'PCI->PKI':False,
				'PCI->MAH':False,
				'PCI->CMH':False,
				'PCA->COR':False,
				'PCA->PRD':False,
				'PCA->MGT':False,
				'PCA->PCI':False,
				'PCA->PKI':False,
				'PCA->MAH':False,
				'PCA->CMH':False,
				'PKI->COR':False,
				'PKI->PRD':False,
				'PKI->MGT':False,
				'PKI->PCI':False,
				'PKI->PCA':False,
				'PKI->MAH':False,
				'PKI->CMH':False,
				'MAH->COR':False,
				'MAH->PRD':False,
				'MAH->MGT':False,
				'MAH->PCI':False,
				'MAH->PCA':False,
				'MAH->PKI':False,
				'MAH->CMH':False,
				'CMH->COR':False,
				'CMH->PRD':False,
				'CMH->MGT':False,
				'CMH->PCI':False,
				'CMH->PCA':False,
				'CMH->PKI':False,
				'CMH->MAH':False,
				'INTERNET->COR':False,
				'INTERNET->PRD':False,
				'INTERNET->MGT':False,
				'INTERNET->PCI':False,
				'INTERNET->PCA':False,
				'INTERNET->PKI':False,
				'INTERNET->MAH':False,
				'INTERNET->CMH':False
			}

if __name__ == "__main__":
	main()