#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse, sqlite3
from sqlite3 import Error
import os, logging, sys, time
from datetime import datetime
from operator import itemgetter
import threading

DONE = True

def main():
	'''
	https://metacpan.org/pod/SQLite::VirtualTable::Pivot
	https://sqlite.org/cli.html#changing_output_formats
	https://www.w3resource.com/sqlite/sqlite-insert-into.php
	'''
	global DONE
	parser = argparse.ArgumentParser()
	opns = parser.add_argument_group('analysis options')
	dbopns = parser.add_argument_group('database options')
	parser.add_argument('-r','--report',action='store',dest='rep',help='Print output to directory supplied')
	dbopns.add_argument('-i','--input-file',action='store',dest='hosts',help='Input file directory')
	dbopns.add_argument('-n','--db-name',action='store',dest='name',help='Database name')
	dbopns.add_argument('-l','--load-db',action='store',dest='db',help='Load database file')
	opns.add_argument('-t','--tcp',action='store_true',dest='tcp',help='Analyze TCP ports only')
	opns.add_argument('-u','--udp',action='store_true',dest='udp',help='Analyze UDP ports only')
	opns.add_argument('-N','--num',action='store',dest='n',help='Return this many records')
	opns.add_argument('-z','--zone',action='store',dest='zone',help='Zone to return. Default is ALL ZONES')
	opns.add_argument('-b','--bottom',action='store_true',dest='bottom',help='Returns low ranked port combos')
	opns.add_argument('-T','--top',action='store_true',dest='top',help='Returns high ranked port combos')


	args = parser.parse_args()
	prefixes = ["[*] ", "[x] ", "[+] ", "[-] ", "[?] "]
	protocols = ["tcp","udp"]
	in_path = ""
	out_path = ""
	host_files = []
	file_index = []

	ts = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
	log_file = "analysis-"+ts+".log"
	out_file = "analysis-report-"+ts+".txt"

	if args.db and args.hosts:
		print(prefixes[1]+"You must select either \'-i\' OR \'-l\', not both")
		sys.exit(1)

	if not args.db and args.hosts and not args.name:
		print(prefixes[1]+"You must provide a name for the new database")
		sys.exit(1)

	if args.db and ((not args.tcp and not args.udp) or not args.n):
		print(prefixes[1]+"You must select (\'-t\', \'-u\', or both ) protocol(s), and \'-N\' number of results")
		sys.exit(1)
	elif (args.db and (not args.bottom and not args.top)) or (args.db and (args.bottom and args.top)):
		print(prefixes[1]+"You must select either \'-b\'/\'--bottom\' or \'-T\'/\'--top\' with this option")
		sys.exit(1)
	elif args.db and args.rep:
		if not os.path.isdir(args.rep):
			print(prefixes[1]+"Output path must point to a directory")
			sys.exit(1)
		else:
			out_path = os.path.abspath(args.rep)
			if os.name == 'posix':
				out_path += '/'
			else:
				out_path += '\\'
			out_file = out_path + out_file

	if not args.db:
		if not os.path.isdir(args.hosts):
			print(prefixes[1]+"Input path must point to a directory")
			sys.exit(1)
		else:
			in_path = os.path.abspath(args.hosts)
			if os.name == 'posix':
				in_path += '/'
			else:
				in_path += '\\'
			file_count = len([name for name in os.listdir(args.hosts) if os.path.isfile(os.path.join(args.hosts, name))])
			file_index = list(range(file_count))
			host_files = os.listdir(args.hosts)

	if not os.path.isdir('logs/'):
		os.mkdir('logs/')

	log = logging.getLogger(__name__)
	logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)-8s %(message)s',
					datefmt='%a, %d %b %Y %H:%M:%S', filename='logs/'+log_file, filemode='w')

	log.info("Getting DB connection")
	try:
		if not args.db:
			threads = []
			log.info("Building DB")
			conn = _build_tables(args.name+'.db', log)
			log.info("DB successfully built")
			log.info("Starting zone to file association")
			# Associate files and zones
			while True:
				_clear_term()
				zone_info = _map_files(in_path, host_files, file_index, prefixes)
				print(prefixes[0]+"Please review the following:")
				for zone, file in zone_info.ZONES.items():
					print('\t'+zone+" "+file['in_file'])
				check = input(prefixes[4]+"Does this look correct [y/n]?: ")
				if check.lower() == 'y' or check.lower() == 'yes':
					break
			# Log file associations
			for zone, file in zone_info.ZONES.items():
				if file['in_file'] == "":
					log.info(zone+" NO FILE ASSOCIATION")
				else:
					log.info(zone+" "+file['in_file'])
			log.info("Zone to file association complete")
			log.info("Starting DB load")
			print(prefixes[2]+"Starting database load")

			# Start animation thread
			wait_animate = threading.Thread(target=_animate)
			wait_animate.daemon = True
			DONE = False
			wait_animate.start()

			# Load database
			with conn:

				for zone, file in zone_info.ZONES.items():
					tcp_ports = []
					udp_ports = []
					if file['in_file'] != '':

						with open(file['in_file'], 'r') as db_l:
							host_i = db_l.readlines()

						# Parse input files
						for line in host_i:
							record = line.split('::')

							# Check for UDP ports
							if len(record) > 2:
								# split ports
								if 'U' in record[2]:
									udp = record[2].split(':')
									udp_ports = udp[1].split(',')

							# Get TCP ports
							if 'T' in record[1]:
								tcp = record[1].split(':')
								tcp_ports = tcp[1].split(',')

							srtd_int_tcp = sorted(set(map(int, tcp_ports)))
							srtd_str_tcp = list(map(str, srtd_int_tcp))

							_add_hosts_and_tcp_ports(conn,(record[0].strip(), zone, "TCP", srtd_str_tcp))
							srtd_int_udp = sorted(set(map(int, udp_ports)))
							srtd_str_udp = list(map(str, srtd_int_udp))

							_add_hosts_and_udp_ports(conn,(record[0].strip(), zone, "UDP", srtd_str_udp))
			DONE = True
			wait_animate.join()
			log.info("Database load complete")
		else:
			if args.zone:
				if args.zone.upper() not in ZONE_INFO.ZONE:
					print(prefixes[1]+"COR, PRD, MGT, MAH, CMH, PCI, PKI, and PCA are the available zone options")
					sys.exit(1)
			log.info("Fetching database: "+args.db)
			conn = _get_connection(args.db)

			log.info("Database loaded and ready")
			print(prefixes[2]+"Database loaded and ready")
			log.info("Starting analysis")
			time.sleep(1)
			print(prefixes[0]+"Starting analysis...")
			time.sleep(1)
			print(prefixes[0]+"Fetching your "+str(args.n)+" results")
			time.sleep(1)

			if args.tcp and args.udp:
				report = _get_top_port_combos(conn, zone=args.zone, n=args.n, top=args.top)
			elif args.tcp:
				report = _get_top_port_combos(conn, proto="TCP", zone=args.zone, n=args.n, top=args.top)
			else:
				report = _get_top_port_combos(conn, proto="UDP", zone=args.zone, n=args.n, top=args.top)

			log.info("Analysis complete")
			print(prefixes[0]+"Analysis complete")
			time.sleep(1)
			if args.rep:
				print(prefixes[0]+"Writing report...")
				with open(out_file, 'w') as out:
					if args.zone is None:
						out.write("Port analysis report for all security zones.\n\n")
						for rep in report:
							for rec in rep:
								out.write("Protocol: "+rec['proto']+"\tCount: "+str(rec['count'])+"\tPort Config: "+rec['ports']+"\n")
					else:
						out.write("Port analysis report for security zone: "+args.zone+".\n\n")
						for rep in report:
							for rec in rep:
								out.write("Zone: "+rec['zone']+"\tProtocol: "+rec['proto']+"\tCount: "+str(rec['count'])+"\tPort Config: "+rec['ports']+"\n")
					out.write("\nEnd of report")
				print(prefixes[0]+"Report written to: "+out_file)
				log.info("Report written to: "+out_file)
			else:
				for rep in report:
					for b in rep:
						print(b)

	except IOError as e:
		print("\n"+prefixes[1]+str(e))
		log.exception(str(e))
		sys.exit(1)
	except Error as e:
		print("\n"+prefixes[1]+str(e))
		log.exception(str(e))
		sys.exit(1)
	except KeyboardInterrupt:
		print("\n"+prefixes[1]+"Cancelled")
		log.info("User Cancelled")
		sys.exit(0)

	print(prefixes[3]+"Done")
	log.info("All tasks complete")
	sys.exit(0)

def _get_top_port_combos(conn, proto=None, zone=None, n=None, top=True):
	curr = conn.cursor()
	t_res = []
	u_res = []
	res = []

	if zone is not None:
		t_sql = "SELECT zone,ports,COUNT(*) AS port_qty FROM host_config_tcp WHERE zone='{0}' GROUP BY ports;".format(zone.upper())
		u_sql = "SELECT zone,ports,COUNT(*) AS port_qty FROM host_config_udp WHERE zone='{0}' GROUP BY ports;".format(zone.upper())
	else:
		t_sql = "SELECT ports,COUNT(*) AS port_qty FROM host_config_tcp GROUP BY ports;"
		u_sql = "SELECT ports,COUNT(*) AS port_qty FROM host_config_udp GROUP BY ports;"

	if proto == "TCP" or proto is None:
		curr.execute(t_sql)
		for rec in curr:
			if zone is not None:
				t_res.append({'zone':rec[0],'proto':'TCP','ports':rec[1],'count':rec[2]})
			else:
				t_res.append({'proto':'TCP','ports':rec[0],'count':rec[1]})
		if n is not None:
			if top:
				t_res = sorted(t_res, key=itemgetter('count'))[-int(n):][::-1]
			else:
				t_res = sorted(t_res, key=itemgetter('count'), reverse=True)[-int(n):][::-1]
		else:
			if top:
				t_res = sorted(t_res, key=itemgetter('count'))[::-1]
			else:
				t_res = sorted(t_res, key=itemgetter('count'), reverse=True)[::-1]
		res.append(t_res)

	if proto == "UDP" or proto is None:
		curr.execute(u_sql)
		for rec in curr:
			if zone is not None:
				u_res.append({'zone':rec[0],'proto':'UDP','ports':rec[1],'count':rec[2]})
			else:
				u_res.append({'proto':'UDP','ports':rec[0],'count':rec[1]})
		if n is not None:
			if top:
				u_res = sorted(u_res, key=itemgetter('count'))[-int(n):][::-1]
			else:
				u_res = sorted(u_res, key=itemgetter('count'), reverse=True)[-int(n):][::-1]
		else:
			if top:
				u_res = sorted(u_res, key=itemgetter('count'))[::-1]
			else:
				u_res = sorted(u_res, key=itemgetter('count'), reverse=True)[::-1]
		res.append(u_res)

	return res


def _add_hosts_and_tcp_ports(conn, hosts_and_tcp_ports):
	'''
	Add hosts and ports to host_config_tcp table.

	:param conn: Connection to database
	:param hosts_and_tcp_ports: Tuple of host and port info
	:return none
	'''
	curr = conn.cursor()
	i = 1
	host_id = None
	port_str = ""
	for port in hosts_and_tcp_ports[3]:
		port_str += port
		port_str += ','
	port_str = port_str.rstrip(',')
	curr.execute("INSERT INTO host_config_tcp(ip_address,zone,protocol,ports) VALUES (?,?,?,?)",(hosts_and_tcp_ports[0],hosts_and_tcp_ports[1],hosts_and_tcp_ports[2],port_str))
	conn.commit()

def _add_hosts_and_udp_ports(conn, hosts_and_udp_ports):
	'''
	Add hosts and ports to host_config_udp table.

	:param conn: Connection to database
	:param hosts_and_udp_ports: Tuple of host and port info
	:return none
	'''
	curr = conn.cursor()
	j = 1
	host_id = None
	port_str = ""
	for port in hosts_and_udp_ports[3]:
		port_str += port
		port_str += ','
	port_str = port_str.rstrip(',')
	curr.execute("INSERT INTO host_config_udp(ip_address,zone,protocol,ports) VALUES (?,?,?,?)",(hosts_and_udp_ports[0],hosts_and_udp_ports[1],hosts_and_udp_ports[2],port_str))
	conn.commit()


def _animate():
	'''
	Wait animation thread
	'''
	global DONE
	char = ''
	i = 0
	while True:
		if i % 5 == 0:
			i = 0
			char = ''
			print('\r'+'[+] Loading             ', end='')
		print('\r'+'[+] Loading ' + char, end='')
		time.sleep(0.5)
		if DONE:
			print('\r'+'                 ', end='')
			print('\r'+'[*] Wrapping up..', end='\n')
			break
		char += '.'
		i += 1
	return

def _map_files(base_path, host_files, file_index, prefixes):
	'''
	Determine file to zone relationship

	:param base_path: Absolute file path
	:param host_files: List of file paths
	:param file_index: List of file indexes
	:param prefixes: Stylized terminal output list
	:return zone_info: ZONE_INFO object
	'''
	zone_info = ZONE_INFO()
	while True:
		print(prefixes[0]+"Please map your files to the appropriate zone, or CTRL+C to exit and ENTER to skip\n")
		print(prefixes[0]+"Security Zones:")
		i = 0
		for zn in zone_info.ZONE:
			print('\t('+str(i)+') '+zn)
			i += 1
		print(prefixes[2]+"Select file")
		this_file = host_files[file_index.pop(0)]
		res = input(prefixes[0]+"Which zone maps to "+this_file+"?: ")
		if res is not "" and (int(res) > -1 and int(res) < len(zone_info.ZONE)):
			zone_info.SET_KEY(zone_info.ZONE[int(res)], "in_file", base_path+this_file)

		if len(file_index) == 0:
			break
		else:
			_clear_term()
	_clear_term()
	return zone_info

def _get_protocols(conn):
	'''
	Add protocol IDs to dictionary and return it

	:param conn: Database connection
	:return proto: Dictionary
	'''
	proto = {'tcp':'','udp':''}
	curr = conn.cursor()
	curr.execute(''' SELECT *
					FROM protocols; '''
				)
	for row in curr:
		if row[1] == "tcp":
			proto['tcp'] = row[0]
		else:
			proto['udp'] = row[0]
	return proto

def _add_protocol(conn, proto):
	'''
	Add protocol to zones protocols

	:param conn: Database connection
	:param zone: Protocol to add
	'''
	sql = ''' INSERT INTO protocols(protocol_desc)
				VALUES(?) '''
	cur = conn.cursor()
	cur.execute(sql, (proto,))
	conn.commit()

def _add_zones(conn, zone):
	'''
	Add zone to zones table

	:param conn: Database connection
	:param zone: Zone to add
	:return cur.lastrowid: ID of the record inserted
	'''
	sql = ''' INSERT INTO zones(zone_desc)
			VALUES(?) '''

	cur = conn.cursor()
	cur.execute(sql, (zone,))
	conn.commit()

	return cur.lastrowid

def _add_host_and_port(conn, host_rec):
	'''
	Add host, zone, and port record to host_configs table

	:param conn: Database connection
	:param host_rec: Tuple containing (ip address, zone id, protocol id, and port)
	:return cur.lastrowid: ID of the record inserted
	'''
	sql = ''' INSERT INTO host_configs(ip_address, zone_id, protocol_id, port)
				VALUES(?, ?, ?, ?) '''
	cur = conn.cursor()
	cur.execute(sql, host_rec)
	conn.commit()

	return cur.lastrowid


def _build_tables(db_file, log):
	'''
	Build the database tables

	:param db_file: Filename to open or create
	:param log: Log object
	:return conn: Database connection
	:exception Error: SQL Error
	'''
	create_host_config_tcp = ''' CREATE TABLE IF NOT EXISTS host_config_tcp (
									id integer PRIMARY KEY,
									ip_address char(30) NOT NULL,
									zone text NOT NULL,
									protocol text DEFAULT 'TCP',
									ports text NOT NULL
									);'''
	create_host_config_udp = ''' CREATE TABLE IF NOT EXISTS host_config_udp (
									id integer PRIMARY KEY,
									ip_address char(30) NOT NULL,
									zone text NOT NULL,
									protocol text DEFAULT 'UDP',
									ports text NOT NULL
									);'''
	try:
		log.info("Creating database")
		conn = _get_connection(db_file)
		if conn is not None:
			log.info("Creating tcp table")
			_get_table(conn, create_host_config_tcp)
			log.info("Creating udp table")
			_get_table(conn, create_host_config_udp)
			log.info("Database and tables sucessfully created")
			return conn
		else:
			raise Error("Could not create table")
	except Error as e:
		log.error(str(e))
		raise Error(str(e))

def _get_connection(db_file):
	'''
	create a database connection to the SQLite database
	specified by db_file
	:param db_file: database file
	:return: Connection object or None
	:exception Error: SQL Error
	'''
	conn = None
	try:
		conn = sqlite3.connect(db_file)
		return conn
	except Error as e:
		raise Error(str(e))

def _get_table(conn, create_table_sql):
	'''
	create a table from the create_table_sql statement
	:param conn: Connection object
	:param create_table_sql: a CREATE TABLE statement
	'''
	try:
		c = conn.cursor()
		c.execute(create_table_sql)
	except Error as e:
		raise Error(str(e))

def _clear_term():
	'''
	Clear terminal in MAC, Windows, and Linux
	'''
	if os.name == 'posix':
		os.system('clear')
	else:
		os.system('cls')

class ZONE_INFO:
	'''
	Zone info object
	'''
	ZONE = [
			"COR", "PRD", 
			"MGT", "CMH", 
			"MAH", "PCI",
			"PCA", "PKI"
			]

	def __init__(self):
		# TODO: find will to live
		self.ZONES = {
					"COR":{"in_file":"","out_file":""},
					"MGT":{"in_file":"","out_file":""},
					"PCA":{"in_file":"","out_file":""},
					"PCI":{"in_file":"","out_file":""},
					"PKI":{"in_file":"","out_file":""},
					"PRD":{"in_file":"","out_file":""},
					"MAH":{"in_file":"","out_file":""},
					"CMH":{"in_file":"","out_file":""}
					}

	def SET_KEY(self, zone, key, val):
		'''
		Set ZONE_INFO dict value

		:param zone: Security zone to modify
		:param key: in_file or out_file
		:param val: set to this
		:exception KeyError:"
		'''
		try:
			self.ZONES[zone][key] = val
		except KeyError as e:
			raise KeyError("lol, you're dumb: "+str(e))

if __name__ == "__main__":
	main()