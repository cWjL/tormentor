#!/usr/bin/env python
from datetime import datetime
import xml.etree.ElementTree as ET
import os, sys, argparse
import threading, logging
import json, subprocess
import socket

def main():
	'''
	TODO add functionality
	SET_KEY(self, zone, key, val)
	'''
	parser = argparse.ArgumentParser()
	gather = parser.add_argument_group('required arguments')
	gather.add_argument('-t', '--target-hosts', action='store', dest='hosts', help='Directory containing host IPs', required=True)
	gather.add_argument('-z', '--zone', action='store', dest='zone', help='The zone in which this is being run', required=True)
	gather.add_argument('-i', '--iface', action='store', dest='iface', help='Interface to scan through', required=True)
	parser.add_argument('-o', '--out', action='store', dest='out', help='Output directory')

	args = parser.parse_args()

	prefixes = ["[*] ", "[x] ", "[+] ", "[-] ", "[?] "]
	out_path = in_path = ""

	if args.out and not os.path.isdir(args.out):
		print(prefixes[1]+"Output path must point to a directory")
		sys.exit(1)
	elif args.out:
		out_path = os.path.abspath(args.out)
		if os.name == 'posix':
			out_path += '/'
		else:
			out_path += '\\'

	if not args.hosts or not args.zone or not args.iface:
		parser.print_help()
		sys.exit(1)

	if not os.path.isdir(args.hosts):
		print(prefixes[1]+"Input path must point to a directory")
		sys.exit(1)
	else:
		in_path = os.path.abspath(args.hosts)
		if os.name == 'posix':
			in_path += '/'
		else:
			in_path += '\\'

	ts = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')

	if not os.path.isdir('logs/'):
		os.mkdir('logs/')
		
	log_file = args.zone+"-map-"+ts+".log"

	file_count = len([name for name in os.listdir(args.hosts) if os.path.isfile(os.path.join(args.hosts, name))])
	file_index = list(range(file_count))
	host_files = os.listdir(args.hosts)

	log = logging.getLogger(__name__)
	logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)-8s %(message)s',
					datefmt='%a, %d %b %Y %H:%M:%S', filename='logs/'+log_file, filemode='w')

	log.info("Input directory \'"+args.hosts+"\' contains "+str(file_count)+" files")
	report = _gather_data(log, prefixes, host_files, in_path, file_index, args.zone, args.iface, ts, out_path)
	
	with open(out_path+args.zone+"-map-"+ts+".map", 'w') as rep:
		rep.write("SRC_ZONE "+args.zone+'\n')
		rep.write("SRC_IP "+_get_host_ip()+'\n')
		for zone, file in report.items():
			if file['in_file'] != "":
				rep.write("TARGET_ZONE "+zone+'\n')
				if file['out_file'] != '':
					with open(file['out_file'], 'r') as up:
						up_list = up.readlines()
					for up_host in up_list:
						rep.write(up_host)
	print(prefixes[0]+"Wrote \'"+args.zone+"-map-"+ts+".map\' to "+(out_path if out_path != "" else os.getcwd()))

	sys.exit(0)

def _gather_data(log, prefixes, host_files, in_path, file_index, args_zone, iface, ts, out=None):
	try:
		while True:
			_clear_term()
			zone_info = _map_files(in_path, host_files, file_index, prefixes)
			print(prefixes[0]+"Please review the following:")
			for zone, file in zone_info.ZONES.items():
				print('\t'+zone+" "+file['in_file'])
			check = input(prefixes[4]+"Does this look correct [y/n]?: ")
			if check.lower() == 'y' or check.lower() == 'yes':
				break
	except KeyboardInterrupt:
		print(prefixes[1]+"Cancelled")
		log.info("User Cancelled")
		sys.exit(0)

	log.info("Zone to file association complete")
	for zone, file in zone_info.ZONES.items():
		if zone == args_zone:
			log.info(zone+" CURRENT SCAN LOCATION")
		elif file['in_file'] == "":
			log.info(zone+" NO FILE ASSOCIATION")
		else:
			log.info(zone+" "+file['in_file'])

	# NMAP(file_name, iface, hosts, log)
	scan_list = []
	for zone, file in zone_info.ZONES.items():
		if file['in_file'] != "":
			output = ''
			if out is not None:
				output = out
				output += args_zone+"-"+zone+"-"+ts
			else:
				output = args_zone+"-"+zone+"-"+ts
			scan_list.append(Nmap(output, iface, file['in_file'], log, zone))

	# SET_KEY(self, zone, key, val)
	i = 0
	print(prefixes[0]+"Starting scans")
	for nmap in scan_list:
		print('\r'+prefixes[0]+"Running scan "+str(i)+" of "+str(len(scan_list)), end='')
		log.info("Starting host scan for \'"+nmap.zone+"\' with input file: "+nmap.hosts)
		nmap.run()
		log.info("Completed host scan for \'"+nmap.zone+"\'. XML file: "+nmap.out_file+". TXT file: "+nmap.host_list)
		zone_info.SET_KEY(nmap.zone, "out_file", nmap.host_list)
		i += 1
	print('\r'+"                          ")
	log.info("Scans complete. Generating reports")
	print(prefixes[0]+"Scans complete. Writing report")
	return zone_info.ZONES

def _map_files(base_path, host_files, file_index, prefixes):
	zone_info = ZONE_INFO()
	print(prefixes[0]+"Please map your files to the appropriate zone, or CTRL+C to exit and ENTER to skip")
	while True:
		print(prefixes[0]+"Security Zones:")
		i = 0
		for zn in zone_info.ZONE:
			print('\t('+str(i)+') '+zn)
			i += 1
		print(prefixes[2]+"Select file")
		this_file = host_files[file_index.pop(0)]
		res = input(prefixes[0]+"Which zone maps to "+this_file+"?: ")
		if res is not "" and (int(res) > -1 and int(res) < len(zone_info.ZONE)):
			zone_info.SET_KEY(zone_info.ZONE[int(res)], "in_file", base_path+this_file)

		if len(file_index) == 0:
			break
		else:
			_clear_term()
	_clear_term()
	return zone_info

def _clear_term():
	'''
	Clear terminal
	'''
	if os.name == 'posix':
		os.system('clear')
	else:
		os.system('cls')

def _get_host_ip():
	'''
	Get localhost IPv4 address
	'''
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect(("8.8.8.8", 80))
	my_ip = s.getsockname()[0]
	s.close()
	return my_ip

class Nmap:
	'''
	Nmap host scan object
	'''
	def __init__(self, file_name, iface, hosts, log, zone):
		self.out_file = file_name+".xml"
		self.host_list = file_name+"-up-hosts.txt"
		self.hosts = hosts
		self.iface = iface
		self.cmd = self._get_host_discovery_scanner()
		self._nmap_err = ''
		self._nmap_output = ''
		self.up_hosts = None
		self.log = log
		self.zone = zone

	def _get_host_discovery_scanner(self):
		'''
		Return nmap command
		'''
		return [
		"nmap",
		"-v",
		"-sn",
		"-T4",
		"-e",
		self.iface,
		"-oX",
		self.out_file,
		"-iL",
		self.hosts
		]

	def run(self):
		'''
		Launch the nmap scan, load the resulting xml file, parse it, and add the discovered hosts to a
		list
 		'''
		p = subprocess.Popen(self.cmd, bufsize=100000,
							stdin=subprocess.PIPE,
							stdout=subprocess.PIPE,
							stderr=subprocess.PIPE)

		(self._nmap_output, self._nmap_err) = p.communicate()
		if len(bytes.decode(self._nmap_err)) > 0:
			self.log.info("nmap errors: "+bytes.decode(self._nmap_err))

		self.up_hosts = self._load_results()
		self._write_host_list()

	def _write_host_list(self):
		'''
		Write the up-hosts to disk
		'''
		with open(self.host_list, 'w+') as tmp:
			for host in self.up_hosts:
				tmp.write(host+'\n')

	def _load_results(self):
		'''
		Load nmap XML output, parse it for up-hosts, and add them to a list
		'''
		host_list = []
		xml_tree = ET.parse(self.out_file)
		for elem in xml_tree.findall('host'):
			if elem.find('status').get('state') == "up":
				host_list.append(elem.find('address').get('addr'))
		return host_list

class ZONE_INFO:
	ZONE = [
			"COR", "PRD", 
			"MGT", "CMH", 
			"MAH", "PCI",
			"PCA", "PKI"
			]

	def __init__(self):
		# TODO: find will to live
		self.ZONES = {
					"COR":{"in_file":"","out_file":""},
					"MGT":{"in_file":"","out_file":""},
					"PCA":{"in_file":"","out_file":""},
					"PCI":{"in_file":"","out_file":""},
					"PKI":{"in_file":"","out_file":""},
					"PRD":{"in_file":"","out_file":""},
					"MAH":{"in_file":"","out_file":""},
					"CMH":{"in_file":"","out_file":""}
					}

	def SET_KEY(self, zone, key, val):
		try:
			self.ZONES[zone][key] = val
		except KeyError as e:
			raise KeyError("lol, you're dumb: "+str(e))

if __name__ == "__main__":
	main()