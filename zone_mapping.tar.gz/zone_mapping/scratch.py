def _build_tables(db_file, log):
	'''
	Build the DB tables
	'''

	create_hosts_table_sql = ''' CREATE TABLE IF NOT EXISTS hosts (
									id integer PRIMARY KEY,
									zone text NOT NULL,
									ip_address text NOT NULL
									);'''
	create_tcp_port_table = ''' CREATE TABLE IF NOT EXISTS tcp_ports (
								id integer PRIMARY KEY,
								port integer NOT NULL,
								host_id integer NOT NULL,
								FOREIGN KEY (host_id) REFERENCES hosts (id)
								);'''
	create_udp_port_table = ''' CREATE TABLE IF NOT EXISTS udp_ports (
								id integer PRIMARY KEY,
								port integer NOT NULL,
								host_id integer NOT NULL,
								FOREIGN KEY (host_id) REFERENCES hosts (id)
								);'''
	try:
		log.info("Creating database")
		conn = _get_connection(db_file)
		if conn is not None:
			log.info("Creating hosts table")
			_get_table(conn, create_hosts_table_sql)
			log.info("Creating TCP ports table")
			_get_table(conn, create_tcp_port_table)
			log.info("Creating UDP ports table")
			_get_table(conn, create_udp_port_table)
			log.info("Database and tables sucessfully created")
			return conn
		else:
			raise Error("Could not create table")
	except Error as e:
		log.error(str(e))
		raise Error(str(e))

def _add_tcp_ports(conn, tcp_port):
	'''
	Create a new tcp port
	:param conn:
	:param port:
	'''
	sql = ''' INSERT INTO tcp_ports(port,host_id)
				VALUES(?,?) '''

	cur = conn.cursor()
	cur.execute(sql, tcp_port)
	conn.commit()

	return cur.lastrowid

def _add_udp_ports(conn, udp_port):
	'''
	Create a new udp port
	:param conn:
	:param port:
	'''
	sql = ''' INSERT INTO udp_ports(port,host_id)
				VALUES(?,?) '''

	cur = conn.cursor()
	cur.execute(sql, udp_port)
	conn.commit()

	return cur.lastrowid

def _add_host(conn, host):
	'''
	Add a host to hosts table
	:param conn:
	:param host:
	:return: host id
	'''
	sql = ''' INSERT INTO hosts(zone,ip_address)
				VALUES(?,?) '''

	cur = conn.cursor()
	cur.execute(sql, host)
	conn.commit()
	return cur.lastrowid

def _test_query(conn, zone):
	curr = conn.cursor()
	# Works, but no results if no UDP ports are present
	# curr.execute('''SELECT host.*, tcp.*, udp.*
	# 				FROM hosts AS host
	# 				INNER JOIN tcp_ports AS tcp
	# 				ON host.id = tcp.host_id
	# 				INNER JOIN udp_ports AS udp
	# 				ON host.id = udp.host_id
	# 				WHERE host.zone=?
	# 				LIMIT 20;''',
	# 				(zone,)
	# 				)
	# curr.execute('''SELECT host.ip_address, udp.port
	# 				FROM hosts AS host
	# 				INNER JOIN udp_ports AS udp
	# 				ON host.id = udp.host_id
	# 				WHERE host.zone=?
	# 				ORDER BY udp.port ASC;''',
	# 				(zone,)
	# 				)
	# curr.execute('''SELECT ip_address, tcp.port, udp.port, count(tcp.port), count(udp.port)
	# 				FROM hosts, tcp_ports tcp, udp_ports udp
	# 				WHERE hosts.zone=?
	# 				AND hosts.id = tcp.host_id
	# 				AND hosts.id = udp.host_id
	# 				GROUP BY tcp.port, udp.port;
	# 				''',
	# 				(zone,)
	# 				)
	curr.execute('''SELECT *
					FROM (
						SELECT COUNT(1) AS the_count, tcp_ports.port, 'TCP' AS the_protocol 
						FROM hosts INNER JOIN tcp_ports ON hosts.id == tcp_ports.host_id GROUP BY port
						UNION
						SELECT COUNT(1) AS the_count, udp_ports.port, 'UDP' AS the_protocol
						FROM hosts INNER JOIN udp_ports ON hosts.id == udp_ports.host_id GROUP BY port
						)
					ORDER BY the_count DESC;
					'''
					)
	# Took super long and ate all the processor
	# curr.execute('''SELECT *
	# 				FROM hosts host, tcp_ports tcp, udp_ports udp
	# 				WHERE (
	# 				tcp.host_id = host.id
	# 				OR
	# 				udp.host_id = host.id
	# 				)
	# 				AND host.zone=?;
	# 				''',
	# 				(zone,)
	# 				)
	for row in curr:
		print(row)

def get_port_count_by_zone(conn, zone):
	'''
	Count the number of times a port is seen

	:param conn: Connection the the database
	:param zone: Zone to search
	:return curr: Cursor to the results
	'''
	curr = conn.cursor()
	curr.execute('''SELECT *
				FROM (
					SELECT COUNT(1) AS the_count, tcp_ports.port, 'TCP' AS the_protocol 
					FROM hosts INNER JOIN tcp_ports ON hosts.id == tcp_ports.host_id GROUP BY port
					UNION
					SELECT COUNT(1) AS the_count, udp_ports.port, 'UDP' AS the_protocol
					FROM hosts INNER JOIN udp_ports ON hosts.id == udp_ports.host_id GROUP BY port
					)
				ORDER BY the_count DESC;
				'''
				)
	return curr


def get_tcp_ports_by_zone(conn, zone):
	'''
	Return cursor to query for host/tcp ports by zone

	:param conn: Connection to the database
	:param zone: Zone to search
	:return curr: Cursor of the results
	'''
	curr = conn.cursor()
	curr.execute('''SELECT host.ip_address, udp.port
					FROM hosts AS host
					INNER JOIN udp_ports AS udp
					ON host.id = udp.host_id
					WHERE host.zone=?;''',
					(zone,)
				)
	return curr

def get_udp_ports_by_zone(conn, zone):
	'''
	Return cursor to query for host/udp ports by zone

	:param conn: Connection to the database
	:param zone: Zone to search
	:return curr: Cursor of the results
	'''
	curr = conn.cursor()
	curr.execute('''SELECT host.ip_address, tcp.port
					FROM hosts AS host
					INNER JOIN tcp_ports AS tcp
					ON host.id = tcp.host_id
					WHERE host.zone=?;''',
					(zone,)
				)
	return curr