import json, os, sys, operator

def _collect_ports(res_json):
	'''
	Collect ports for each host
	'''
	hosts = []

	host_index = 0

	for host in res_json:
		if len(hosts) == 0:
			hosts.append(Host(host['ip']))
		elif hosts[host_index].ip != host['ip']:
			hosts.append(Host(host['ip']))
			host_index += 1

		for attrib in host['ports']:
			if attrib['proto'] == "tcp":
				hosts[host_index].add_tcp_port(attrib['port'])
			elif attrib['proto'] == "udp":
				hosts[host_index].add_udp_port(attrib['port'])

	return hosts

def _load_results(in_file):
	'''
	Get output file and load JSON

	Validate JSON using https://jsonlint.com/.
	'''

	# Check if masscan added a trailing ',', which is does (but check just in case)
	with open(os.path.abspath(in_file)) as frmt:
		data = frmt.readlines()

	if len(data) < 1:
		raise ValueError("Scan results empty")

	# Remove it and write the file back
	if data[len(data)-2].rfind(',') == (len(data[len(data)-2])-2):
		repl = data[len(data)-2][:data[len(data)-2].rfind(',')] + data[len(data)-2][data[len(data)-2].rfind(',')+1:]
		data[len(data)-2] = repl
		with open(os.path.abspath(in_file), 'w') as refrmt:
			refrmt.write("\n".join(data))

	# Load JSON 
	with open(os.path.abspath(in_file)) as load_res:
		data = json.load(load_res)

	return data

class Host:
	def __init__(self, ip):
		self.ip = ip
		self.tcp_ports = []
		self.udp_ports = []

	def add_tcp_port(self, port):
		self.tcp_ports.append(port)

	def add_udp_port(self, port):
		self.udp_ports.append(port)

	def get_port_string(self):
		return _stringify_ports()

	def get_host_and_port_string(self):
		return self.ip + "::" + self._stringify_ports()

	def _stringify_ports(self):
		port_string = ""
		if len(self.tcp_ports) > 0:
			port_string += "T:"
			for tcp_port in self.tcp_ports:
				if len(port_string) > 2:
					port_string += ','
				port_string += str(tcp_port)
		if len(self.udp_ports) > 0:
			if len(port_string) == 0:
				port_string += "U:"
			else:
				port_string += "::U:"
			i = 0
			for udp_port in self.udp_ports:
				if i != 0:
					port_string += ','
				port_string += str(udp_port)
				i += 1
		return port_string

def test_kwargs(**kwargs):
	a = kwargs['a']
	b = kwargs['b']
	return a+b

# res_json = _load_results("out.json")
# #print(res_json)
# #sys.exit(0)
# res_json.sort(key=operator.itemgetter('ip'))
# host_report = _collect_ports(res_json)
# for host in host_report:
# 	print(host.get_host_and_port_string())
print(test_kwargs(a=None, b="there"))


