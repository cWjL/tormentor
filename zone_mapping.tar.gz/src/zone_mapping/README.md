# zone_mapping
Host and port scanning reconnaissance script using nmap and masscan.

**File Output**

The Script will produce the following files:

* nmap-\<time stamp\>.xml
  * Raw nmap XML output
* nmap-\<time stamp\>-up-hosts.txt
  * Hosts nmap has determined are "Up" ('\n' separated list)
* masscan-\<time stamp\>.json
  * Raw masscan JSON output
* masscan-\<time stamp\>-hosts-and-ports.txt
  * Hosts and associated ports ('\n' separated list)
  * **Format:** x.x.x.x::T:\<tcp port\>, \<tcp port\>::U:\<udp port\>, \<udp port\>
  
Logs will be generated in the following location/file name:

* zone_mapping/logs/recon-\<time stamp\>.log

## Python Version
```
Python3.X
```
## Host Requirements
```
Min 4GB RAM, 2vCPU, 20GB Free Storage
```
## Host Setup
```
sudo yum install python3 nmap gcc make libpcap-devel.x86_64
git clone https://github.com/robertdavidgraham/masscan
cd masscan
make
sudo cp bin/masscan /usr/local/bin/
cd ../
```

## Script Installation and Setup
```
git clone https://github.secureserver.net/SRA/zone_mapping.git
cd zone_mapping/
python3 -m pip install -r requirements.txt
```

## Usage
```
usage: recon.py [-h] [-n] [-m] [-d] [-p PORTS] [-u] [-f HOSTS] [-s SUBS]
                [-r RATE] [-i IFACE]

optional arguments:
  -h, --help              show this help message and exit

mode selection:
  -n, --nmap-discovery    Run nmap host discovery scan on subnet(s)
  -m, --masscan           Run masscan port scans
  -d, --port-discovery    Run host discovery and dump results into masscan for
                          port discovery

option arguments:
  -p PORTS, --ports PORTS Comma separated list of ports or ranges - default is 1-65535
  -u, --udp               Include UDP in port scanning
  -f HOSTS, --hosts HOSTS Filepath to hosts you want to scan
  -s SUBS, --subnets SUBS Filepath to subnets you want to scan
  -r RATE, --rate RATE    Scan rate - 1000 is default
  -i IFACE, --iface IFACE Interface to scan through
```

## Usage Example
```
$ python3 recon.py -i eth0 -d -u -s mgt.txt -r 10000
```
## Considerations

Depending on the number of subnets passed to nmap, and the number of hosts discovered, a large scan may take several hours to complete, even with a high scan rate passed to masscan ('-r' at ~5000+). This may pose a problem if launched from a remote host via an SSH connection over VPN (which is disconnect prone).

Consider using `screen` to background the terminal session, and checking back periodically to see if the process has finished:
```
[user@host zone_mapping]$ screen
[user@host zone_mapping]$ python3 recon.py -i eth0 -d -u -s mgt.txt -r 10000
[+] This option needs sudo. Please provide sudo password: 
[*] Starting host and port discovery scans
[*] Starting host discovery.  This may take awhile...
[*] Scanning /
<CTRL> + a, d
```
The session will be moved to the background, at which point you can exit out of the SSH session.

To return, log back in to the host, and switch back to the backgrounded session using `screen -r`:
```
user@LM-USERMACHINE ~ % ssh user@host.server.site.gdg
Password:
Last login: Wed Aug  5 07:24:00 2020 from 10.X.X.X
Authorized Access Only
[user@host]$ screen -r
[user@host zone_mapping]$ python3 recon.py -i eth0 -d -u -s mgt.txt -r 10000
[+] This option needs sudo. Please provide sudo password: 
[*] Starting host and port discovery scans
[*] Starting host discovery.  This may take awhile...
[*] Scanning /
```
To determine if the script has finished without jumping back into it, you can either check to see if the process is still running:
```
[user@host]$ ps aux | grep python
root     652  0.0  0.7 583964 13960 ?        Ssl  Jul31   1:10 /usr/bin/python2 -Es /usr/sbin/tuned -l -P
user    2350  0.0  0.0 112812   968 pts/0    S+   09:27   0:00 grep --color=auto python
user    8073  0.2  3.2 370788 61088 pts/1    Sl+  08:01   0:12 python3 recon.py -i eth0 -d -u -s mgt.txt -r 10000
```
Or check for the existence of the `masscan-<time stamp>-hosts-and-ports.txt` file in the script root directory.

To end the screen session following a successful scan, first find it's process ID, then kill it:
```
[user@host]$ screen -list
There is a screen on:
	    8609.pts-0.fw-proj-mgt	(Detached)
1 Socket in /var/run/screen/S-user.

[user@host]$ screen -S 8609 -X quit
[user@host]$ screen -list
No Sockets found in /var/run/screen/S-user.
```
