#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse, threading
import os, logging, sys, time
import subprocess, itertools
import json, socket, operator
from datetime import datetime
import xml.etree.ElementTree as ET
import traceback
from getpass import getpass

DONE = False

def main():
	'''
	Recon scanning using nmap and masscan
	'''
	global DONE
	parser = argparse.ArgumentParser()
	mode = parser.add_argument_group('mode selection')
	opns = parser.add_argument_group('option arguments')
	mode.add_argument('-n', '--nmap-discovery', action='store_true', dest='nmap', help='Run nmap host discovery scan on subnet(s)')
	mode.add_argument('-m', '--masscan', action='store_true', dest='masscan', help='Run masscan port scans')
	mode.add_argument('-d', '--port-discovery', action='store_true', dest='prtdisc', help='Run host discovery and dump results into masscan for port discovery')
	opns.add_argument('-p', '--ports', action='store', dest='ports', help='Comma separated list of ports or ranges - default is 1-65535')
	opns.add_argument('-u','--udp', action='store_true', dest='udp', help='Include UDP in port scanning')
	opns.add_argument('-f', '--hosts', action='store', dest='hosts', help='Filepath to hosts you want to scan')
	opns.add_argument('-s','--subnets', action='store', dest='subs', help='Filepath to subnets you want to scan')
	opns.add_argument('-r', '--rate', action='store', dest='rate', help='Scan rate - 1000 is default')
	opns.add_argument('-i', '--iface', action='store', dest='iface', help='Interface to scan through')

	args = parser.parse_args()

	prefixes = ["[*] ", "[x] ", "[+] ", "[-] "]

	if args.nmap and args.masscan:
		print(prefixes[1]+"You must select nmap OR masscan, not both.  Use \'-d\' or \'--port-discovery\' for that")
		sys.exit(1)

	if not args.nmap and not args.masscan and not args.prtdisc:
		print(prefixes[1]+"You must select nmap OR masscan OR port-discovery")
		sys.exit(1)

	if args.masscan and not (args.iface and args.hosts):
		print(prefixes[1]+"Masscan option requires the following arguments at a minimum:")
		print("\t-i, --iface")
		print("\t-f, --hosts")
		print(prefixes[1]+"The following are optional:")
		print("\t-r, --rate")
		print("\t-p, --ports")
		sys.exit(1)

	if args.nmap and not (args.iface and args.subs):
		print(prefixes[1]+"Nmap option requires the following arguments at a minimum:")
		print("\t-i, --iface")
		print("\t-s, --subnets")
		sys.exit(1)

	if args.prtdisc and not (args.iface and args.subs):
		print(prefixes[1]+"Port Discovery option requires the following arguments:")
		print("\t-i, --iface")
		print("\t-s, --subnets")
		sys.exit(1)

	try:
		ts = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')

		if not os.path.isdir('logs/'):
			os.mkdir('logs/')
			
		log_file = "recon-"+ts+".log"

		log = logging.getLogger(__name__)
		logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)-8s %(message)s',
						datefmt='%a, %d %b %Y %H:%M:%S', filename='logs/'+log_file, filemode='w')
		if args.nmap:
			wait = threading.Thread(target=animate)
			print(prefixes[0]+"Starting host discovery")
			start_time = datetime.now()
			wait.start()
			nmap = Nmap(ts, args.iface, args.subs, log)
			log.info("Host discovery scan started. CMD: "+str(nmap.cmd))
			nmap.run()
			DONE = True
			time.sleep(1)
			print(prefixes[0]+"Host discovery complete")
			print(prefixes[0]+"See files: " + nmap.out_file +" and "+nmap.host_list)
			log.info("Host discovery scan completed. Output files: "+nmap.out_file+", "+nmap.host_list)
			log.info('Duration: {}'.format(datetime.now() - start_time))
		elif args.masscan:
			sudo  = getpass(prefixes[2]+"This option needs sudo. Please provide sudo password: ")
			print(prefixes[0]+"Starting port scan")
			wait = threading.Thread(target=animate)
			#(iface, tar, sudo, log, rate=1000, ports="1-65535", udp=False)
			if args.rate is not None and args.ports is not None:
				masscan = Masscan(ts, args.iface, args.hosts, sudo, log, rate=args.rate, ports=args.ports, udp=args.udp)
			elif args.rate is not None and args.ports is None:
				masscan = Masscan(ts, args.iface, args.hosts, sudo, log, rate=args.rate, udp=args.udp)
			elif args.rate is None and args.ports is not None:
				masscan = Masscan(ts, args.iface, args.hosts, sudo, log, ports=args.ports, udp=args.udp)
			else:
				masscan = Masscan(ts, args.iface, args.hosts)
			log.info("Port discovery scan started. CMD: "+str(masscan.cmd))
			start_time = datetime.now()
			masscan.run()
			print(prefixes[0]+"Port discovery complete")
			print(prefixes[0]+"See file: " + masscan.out_file)
			log.info("Port discovery scan completed. Output files: "+masscan.out_file)
			log.info('Duration: {}'.format(datetime.now() - start_time))
		elif args.prtdisc:
			sudo  = getpass(prefixes[2]+"This option needs sudo. Please provide sudo password: ")
			print(prefixes[0]+"Starting host and port discovery scans")
			print(prefixes[0]+"Starting host discovery.  This may take awhile...")
			nmap = Nmap(ts, args.iface, args.subs, log)
			log.info("Host discovery scan started. CMD: "+str(nmap.cmd))
			start_time = datetime.now()
			wait = threading.Thread(target=animate)
			wait.start()
			nmap.run()
			DONE = True
			time.sleep(1)
			print(prefixes[0]+"Host discovery complete")
			if args.rate is None and args.ports is None:
				masscan = Masscan(ts, args.iface, nmap.host_list, sudo, log, udp=args.udp)
			elif args.rate is None:
				masscan = Masscan(ts, args.iface, nmap.host_list, sudo, log, ports=args.ports, udp=args.udp)
			else:
				masscan = Masscan(ts, args.iface, nmap.host_list, sudo, log, rate=args.rate, udp=args.udp)
			print(prefixes[0]+"Starting port scan")
			print(prefixes[0]+"This will take even longer than host discovery, so buckle up...")
			log.info("Port discovery scan started. CMD: "+str(masscan.cmd))
			wait = threading.Thread(target=animate)
			DONE = False
			wait.start()
			masscan.run()
			DONE = True
			time.sleep(1)
			print(prefixes[0]+"Port discovery scan complete")
			print(prefixes[0]+"See files: "+masscan.host_port_report+" and "+masscan.out_file)
			log.info("Port discovery scan completed. Output files: "+masscan.out_file+", "+masscan.host_port_report)
			log.info('Duration: {}'.format(datetime.now() - start_time))
	except ValueError as e:
		log.error("ValueError: "+str(e))
		log.error(traceback.format_exc())
		print(prefixes[1]+str(e))
		DONE = True
		sys.exit(1)
	except IOError as e:
		log.error("IOError: "+str(e))
		log.error(traceback.format_exc())
		print(prefixes[1]+str(e))
		DONE = True
		sys.exit(1)
	except TypeError as e:
		log.error("TypeError: "+str(e))
		log.error(traceback.format_exc())
		print(prefixes[1]+str(e))
		DONE = True
		sys.exit(1)
	log.info("Process complete. Exiting")
	sys.exit(0)

def animate():
	'''
	Wait animation thread
	'''
	global DONE
	for c in itertools.cycle(['|', '/', '-', '\\']):
		print('\r'+'[*] Scanning ' + c, end='')
		time.sleep(0.1)
		if DONE:
			print('\r'+'                ', end='')
			print('\r'+'[*] Done', end='\n')
			break


class Masscan:
	'''
	Masscan port discovery scanner object
	'''
	def __init__(self, ts, iface, tar, sudo, log, rate=1000, ports="1-65535", udp=False):
		self.rate = str(rate)
		self.ts = ts
		self.iface = iface
		self.file_base = "masscan-"+self.ts
		self.out_file = self.file_base+".json"
		self.host_port_report = self.file_base+"-hosts-and-ports.txt"
		if udp == True:
			self.ports = ports+",U:"+ports
		else:
			self.ports = ports
		self.targets = tar
		self.sudo = sudo
		self.res_json = None
		self._masscan_output = ''
		self._masscan_err = ''
		self.host_report = []
		self.log = log
		self.cmd = self._get_port_scanner()

	def _get_port_scanner(self):
		'''
		Return Masscan command
		'''
		return [
		"masscan",
		"-v",
		"--open",
		"--banners",
		"--rate",
		self.rate,
		"-e",
		self.iface,
		"-oJ",
		self.out_file,
		"-p",
		self.ports,
		"-iL",
		self.targets
		]

	def _get_file_perm(self):
		'''
		Change permissions for json ouput
		'''
		return [
		"chmod",
		"777",
		self.out_file
		]

	def _get_host_ip(self):
		'''
		Get localhost IPv4 address
		'''
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.connect(("8.8.8.8", 80))
		my_ip = s.getsockname()[0]
		s.close()
		return my_ip

	def _write_overview_report(self):
		'''
		Write the output of _collect_ports to disk
			This will produce a test file in the following format:
				x.x.x.x::T:<tcp port>, <tcp port>::U:<udp port>, <udp port>
		'''
		with open(self.host_port_report, 'w+') as overview:
			for host in self.host_report:
				overview.write(host+'\n')

	def run(self):
		'''
		Launch the masscan, load the resulting json file, sort it by IPv4 address, 
		then run port aggregator (_collect_ports())
 		'''
		scan_p = subprocess.Popen(['sudo', '-S']+self._get_port_scanner(), bufsize=100000,
							stdin=subprocess.PIPE,
							stdout=subprocess.PIPE,
							stderr=subprocess.PIPE)
		self.sudo += '\n'
		(self._masscan_output, self._masscan_err) = scan_p.communicate(self.sudo.encode())

		mod_p = subprocess.Popen(['sudo', '-S']+self._get_file_perm(), bufsize=100000,
							stdin=subprocess.PIPE,
							stdout=subprocess.PIPE,
							stderr=subprocess.PIPE)

		(self._chmod_output, self._chmod_err) = mod_p.communicate(self.sudo.encode())
		#log subprocess info
		self.log.info("masscan output: "+bytes.decode(self._masscan_output))
		self.log.info("masscan errors: "+bytes.decode(self._masscan_err))
		self.log.info("chmod output: "+bytes.decode(self._chmod_output))
		self.log.info("chmod error: "+bytes.decode(self._chmod_err))
		#get the masscan json output
		self.res_json = self._load_results()
		#sort the masscan json output
		self.res_json.sort(key=operator.itemgetter('ip'))
		#aggregate ports and write to disk
		self._collect_ports()

	def _collect_ports(self):
		'''
		Aggregate TCP/UDP ports by IPv4 address, add the resulting list to self.host_report
		and write it to disk
		'''
		hosts = []

		host_index = 0

		for host in self.res_json:
			if len(hosts) == 0:
				hosts.append(Masscan.Host(host['ip']))
			elif hosts[host_index].ip != host['ip']:
				hosts.append(Masscan.Host(host['ip']))
				host_index += 1

			for attrib in host['ports']:
				if attrib['proto'] == "tcp":
					if attrib['port'] not in hosts[host_index].tcp_ports:
						hosts[host_index].add_tcp_port(attrib['port'])
				elif attrib['proto'] == "udp":
					if attrib['port'] not in hosts[host_index].udp_ports:
						hosts[host_index].add_udp_port(attrib['port'])

		for host in hosts:
			self.host_report.append(host.get_host_and_port_string())

		self._write_overview_report()

	def _load_results(self):
		'''
		Get output file and load JSON
		'''

		# Check if masscan added a trailing ',', which is does, but check just in case
		with open(os.path.abspath(self.out_file)) as frmt:
			data = frmt.readlines()

		if len(data) < 1:
			raise ValueError("Scan results empty")

		# Remove it and write the file back
		if data[len(data)-2].rfind(',') == (len(data[len(data)-2])-2):
			repl = data[len(data)-2][:data[len(data)-2].rfind(',')] + data[len(data)-2][data[len(data)-2].rfind(',')+1:]
			data[len(data)-2] = repl
			with open(os.path.abspath(self.out_file), 'w') as refrmt:
				refrmt.write("\n".join(data))

		# Load JSON 
		with open(os.path.abspath(self.out_file)) as load_res:
			data = json.load(load_res)

		return data

	def print_result_json(self):
		'''
		Pretty print output json
		'''
		if self.res_json is not None:
			print(json.dumps(self.res_json, indent=4, sort_keys=True))
		else:
			raise ValueError("There are no results to print")

	class Host:
		'''
		Host object for storing/sorting/reporting host related info
		'''
		def __init__(self, ip):
			self.ip = ip
			self.tcp_ports = []
			self.udp_ports = []

		def add_tcp_port(self, port):
			self.tcp_ports.append(port)

		def add_udp_port(self, port):
			self.udp_ports.append(port)

		def get_port_string(self):
			return _stringify_ports()

		def get_host_and_port_string(self):
			return self.ip + "::" + self._stringify_ports()

		def _stringify_ports(self):
			port_string = ""
			if len(self.tcp_ports) > 0:
				port_string += "T:"
				for tcp_port in self.tcp_ports:
					if len(port_string) > 2:
						port_string += ','
					port_string += str(tcp_port)
			if len(self.udp_ports) > 0:
				if len(port_string) == 0:
					port_string += "U:"
				else:
					port_string += "::U:"
				i = 0
				for udp_port in self.udp_ports:
					if i != 0:
						port_string += ','
					port_string += str(udp_port)
					i += 1
			return port_string

class Nmap:
	'''
	Nmap host scan object
	'''
	def __init__(self, ts, iface, subs, log):
		self.ts = ts
		self.file_base = "nmap-"+self.ts
		self.out_file = self.file_base+".xml"
		self.host_list = self.file_base+"-up-hosts.txt"
		self.subnets = subs
		self.iface = iface
		self.cmd = self._get_host_discovery_scanner()
		self._nmap_err = ''
		self._nmap_output = ''
		self.up_hosts = None
		self.log = log

	def _get_host_discovery_scanner(self):
		'''
		Return nmap command
		'''
		return [
		"nmap",
		"-v",
		"-sn",
		"-e",
		self.iface,
		"-oX",
		self.out_file,
		"-iL",
		self.subnets
		]

	def run(self):
		'''
		Launch the nmap scan, load the resulting xml file, parse it, and add the discovered hosts to a
		list
 		'''
		p = subprocess.Popen(self.cmd, bufsize=100000,
							stdin=subprocess.PIPE,
							stdout=subprocess.PIPE,
							stderr=subprocess.PIPE)

		(self._nmap_output, self._nmap_err) = p.communicate()

		self.log.info("nmap errors: "+bytes.decode(self._nmap_err))

		self.up_hosts = self._load_results()
		self._write_host_list()

	def _write_host_list(self):
		'''
		Write the up-hosts to disk
		'''
		with open(self.host_list, 'w+') as tmp:
			for host in self.up_hosts:
				tmp.write(host+'\n')

	def _load_results(self):
		'''
		Load nmap XML output, parse it for up-hosts, and add them to a list
		'''
		host_list = []
		xml_tree = ET.parse(self.out_file)
		for elem in xml_tree.findall('host'):
			if elem.find('status').get('state') == "up":
				host_list.append(elem.find('address').get('addr'))
		return host_list

if __name__ == "__main__":
	main()